# Packaging

Make a tar of the `avs-commons-logging-nodejs` folder.

# Installation

Copy the file `avs-commons-logging-nodejs.tar` in the application root folder.
Wherever you need to use the logger, you must include the library in the following way:

```javascript
var logger = require('avs-commons-logging-nodejs')(filename, level, datePattern);
```

You have to pass the following parameters:

Parameter | Value
--- | ---
filename | Path to the log file (`logs/log.log`)
level | Log level (`TRACE`, `DEBUG`, `INFO`, `ERROR`)
datePattern | Date pattern to append on the filename (`.yyyy-MM-dd`)

# Usage

Library exposes the following:
Type | Name | Description | Log level
--- | --- | --- | ---
Object | `mdcKeys` | Map containing following keys to support the valorization of `mdc` map: `APP_ID`, `THREAD`, `SID`, `TN`, `CLIENT_IP`, `API_TYPE`, `USER`, `API`, `PLATFORM` |
Object | `mdc` | Map containing informations to use on each log line (ex. *appId, thread, SID, ...*) |
Object | `otherSystemCallType` | Map containing following keys to support calls to methods related to the other system calls: `INTERNAL`, `EXTERNAL` |
Object | `errorType` | Map containing following keys to support calls to the method related to the exceptions logging: `CONFIGURATION_ERROR`, `UNEXPECTED_ERROR`, `CONNECTION_ERROR`, `DATABASE_ERROR` |
Method | `logStartApi` | Initializes the `mdc` map using parameters passed in input and logs a line for the start of an API | INFO
Method | `logEndApi` | Logs a line for the end of an API containing User-Agent, request and response informations and destroys `mdc` map | INFO
Method | `logRequestHeader` | Logs a line containing the request headers formatted as `{key=value}` | DEBUG
Method | `logRequestBody` | If request method is one of `POST` or `PUT`, logs a line containing the request body | INFO
Method | `logResponseBody` | Logs a line containing the resulting response | INFO
Method | `logCallToOtherSystemEnd` | Logs a line containing request, response and execution time informations regarding the call to other system. Last parameter must be one of the following: `logger.otherSystemCallType.INTERNAL`, `logger.otherSystemCallType.EXTERNAL` | INFO
Method | `logCallToOtherSystemRequestBody` | Logs a line containing request informations regarding the call to other system. Last parameter must be one of the following: `logger.otherSystemCallType.INTERNAL`, `logger.otherSystemCallType.EXTERNAL` | DEBUG
Method | `logCallToOtherSystemResponseBody` | Logs a line containing response informations regarding the call to other system. Last parameter must be one of the following: `logger.otherSystemCallType.INTERNAL`, `logger.otherSystemCallType.EXTERNAL` | DEBUG
Method | `trace` | Logs a generic line using `TRACE` level | TRACE
Method | `debug` | Logs a generic line using `DEBUG` level | DEBUG
Method | `info` | Logs a generic line using `INFO` level | INFO
Method | `error` | Logs a line containing informations related to the error passed in input | ERROR
Method | `logException` | Logs the stack trace related to the error passed in input. Last parameter must be one of the following: `logger.errorType.CONFIGURATION_ERROR`, `logger.errorType.UNEXPECTED_ERROR`, `logger.errorType.CONNECTION_ERROR`, `logger.errorType.DATABASE_ERROR` | ERROR